IMPORTANT
To avoid cracks in the shadows or light leaking through objects, change the Bias setting to 0.2 or higher and the Normal Bias setting to 0 in your directional light.

License

Thank you for buying the LowPoly Trees and Rocks Pack. You are free to use it for your personal and commercial projects.

You are not allowed to redistribute any or all models of this package in any shape or form unless it is embedded in your own project.

Simply put, you cannot resell or redistribute anything in this package by itself. You can only put it in your games for use as intended.